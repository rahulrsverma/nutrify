//database connection using npm-mngodb

const uri = "mongodb+srv://rahul:rahul@cluster0.jsfsi.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";

//mongodb+srv://rahul:rahul@cluster0.jsfsi.mongodb.net/myFirstDatabase?retryWrites=true&w=majority

const MongoClient=require('mongodb').MongoClient;


const dbClient=new MongoClient( uri ,{ useUnifiedTopology:true});
    dbClient.connect()
        .then(()=>{console.log(" Db connected")})
        .catch((err)=>{console.log(err)})
module.exports=dbClient;
