const { promiseImpl } = require("ejs");
const shortid = require("shortid");
const dbClient = require("../Databases")

const addNewMeal=function(meal,userDetail){
    return new Promise((resolve,reject)=>{
        const db=dbClient.db('Nutrify');
        const dbCollection=db.collection('meals');
        
        dbCollection.insertOne({
                userID:userDetail.email,
                Date: new Date(),
                mealid:shortid.generate(),
                mealType:meal.mealType,
                meal:meal.meal,
                calorie:meal.calorie
            }).then((dbRes) => {
                console.log(dbRes)
                resolve()
            })
            .catch((err) => {
                reject(err);
            })
    })
}
module.exports.addNewMeal=addNewMeal;

const updateMeal =function(meal,userDetail){
    return new Promise((resolve,reject)=>{
        
        const db =dbClient.db('Nutrify');
        const dbCollection=db.collection('meals');

       dbCollection.updateOne({ id:meal.mealid },{$set:{meal:meal.meal,
            mealType:meal.mealType,
            calorie:meal.calorie
            }}).then((dbRes) => {
            console.log(dbRes)
            resolve()
        })
        .catch((err) => {
            reject(err);
        })
})
}
    
module.exports.updateMeal=updateMeal;




const deleteMeal =function(meal,userDetail){
    console.log(meal.mealid)
    return new Promise((resolve,reject)=>{
        const db =dbClient.db('Nutrify');
        const dbCollection=db.collection('meals');
        dbCollection.deleteOne({mealid:meal.mealid})        
    
}).then((dbRes) => {
            
            resolve()
        })
        .catch((err) => {
            reject(err);
        })
}
module.exports.deleteMeal=deleteMeal;



const findallMeal =function(meal,userDetail){
    console.log(meal.mealid)
    return new Promise((resolve,reject)=>{
        const db =dbClient.db('Nutrify');
        const dbCollection=db.collection('meals');
        dbCollection.findOne({userid:userDetail.email})        
    
}).then((dbRes) => {
            
            resolve()
        })
        .catch((err) => {
            reject(err);
        })
}
module.exports.findallMeal=findallMeal;




























