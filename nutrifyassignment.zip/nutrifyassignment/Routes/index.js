 const express = require('express')
 const router=express.Router()
 
 const jwt =require('jsonwebtoken')




 const authRouter=require('./auth')
 const mealRouter=require('./meal')



var isUserSignedIn = (req, res, next) => {
    if (req.headers.cookie) {
        const token = req.headers.cookie.split("=")[1];
        jwt.verify(token, 'secret', (err, userDetails) => {
            if (userDetails && userDetails.email) {
                req.userDetails = userDetails;
                next();
            }  else {
                res.sendStatus(401);
            }
        });
    } else {
        res.sendStatus(401);
    }}




 router.get('/', (req, res) => {
	res.render('welcome');
})


router.get("/home",isUserSignedIn,(req,res)=>{

    
    res.render("home.ejs" ,req.userDetails)
    
})














router.use("/auth",authRouter)



router.use("/meal",isUserSignedIn,mealRouter)
module.exports=router;
module.exports.isUserSignedIn=isUserSignedIn;
