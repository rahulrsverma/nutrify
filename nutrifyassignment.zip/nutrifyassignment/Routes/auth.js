const express = require('express');
const router=express.Router();
const jwt =require('jsonwebtoken')



const {createUser}=require('../Controllers/auth.js')
const {verifyUser}=require('../Controllers/auth.js')




router.get("/register",(req,res)=>{
    res.render('register.ejs')
})



router.post('/register', (req, res) => {
    createUser(req.body)
            .then((response) => {
                res.redirect('/auth/login');
            })
            .catch((err) => {
                console.log('Error: ', err);
                res.send(err);
            })
            })




router.get('/login', (req, res)  => {
    res.render('login', {
        message: ''
    });
})



router.post('/login', (req, res) => {
    verifyUser(req.body, (err, data) => {
        if (err) {
            console.log('err:', err);
            res.sendStatus(500);
        } else if (data && data.message) {
            res.render('login', data);
        } else {
            /********* USING EXPRESS SESSION *********/
            // req.session.email = data.email;
            // req.session.is_admin = true;
            // res.redirect('/home');
            
            /********* USING JWT *********/
            const token = jwt.sign({
                user_id: data.user_id,
                email: data.email,
                is_admin: true
            }, 'secret');
            res.cookie('token', token, {
                httpOnly: true,
            	secure: false
            });
            res.redirect('/home');
        }
    })
})

//router.post('/login', (req, res) => {
//    verifyUser(req.body, (err, data) => {
//        if (err) {
//            console.log('err:', err);
//            res.sendStatus(500);
//        } else if (data && data.message) {
//            console.log(data)
//            res.render('login', data);
//            console.log(res.cookie)
//        } else {
//            const token = jwt.sign({
//                user_id: data.user_id,
//                email: data.email,
//                    is_admin: true
//                }, 'secret');
//                res.cookie('token', token, {
//                    httpOnly: true,
//                    secure: false
//                });
//                res.redirect('/home');
//            }
//        })
//
//})
    
module.exports = router;