const express = require('express');
const router =express.Router()

const {addNewMeal,updateMeal,deleteMeal,findallMeal}=require('../Controllers/meal')




router.get('/addmeal',(req,res)=>{

    res.render("addmeal",req.userDetails)
})





router.post("/addmeal",((req,res)=>{
    addNewMeal(req.body,req.userDetails).
    then((response) => {
        res.redirect('/home')
    })
    .catch((err) => {
        console.log('Error: ', err);
    })
    }))

router.get('/updatemeal',(req,res)=>{
        res.render("updatemeal",req.userDetails)
    })
    
    
    
    
    
router.post("/updatemeal",((req,res)=>{
    updateMeal(req.body,req.userDetails).
    then((response) => {
        res.redirect('/home')
        })
        .catch((err) => {
            console.log('Error: ', err);
        })
        }))
        






router.get('/deletemeal',(req,res)=>{
    res.render("deleteMeal",req.userDetails)
    })
        
router.post("/deletemeal",((req,res)=>{
    deleteMeal(req.body,req.userDetails).
    then((response) => {
        res.redirect('/home')
            })
        .catch((err) => {
        console.log('Error: ', err);
            })
}))
    



router.get('/findallMeal',(req,res)=>{
    res.render(req.userDetails)
    })
        
router.post("/findallMeal",((req,res)=>{
    let allmeals=findallMeal(req.body,req.userDetails).
    then((response) => {
        res.send(allmeals)
            })
        .catch((err) => {
        console.log('Error: ', err);
            })
}))
        
    
    


module.exports=router;