const express = require('express')
const server = express()
const port =8000


const indexRouter=require('./Routes/index.js')

    server.use(express.json());
    server.use(express.urlencoded({ extended: false }));
    server.use(express.static(__dirname + '/Public'))
    server.set('views', 'Views');
    server.set('view engine', 'ejs');


//Error handling part

const errorHandler = function(err, req, res, next) {
	if (err) {
		console.error('Error: ', err);
		res.sendStatus(500);
	}
}

server.use(errorHandler);

//Port no. declaration for localhost

server.use("/",indexRouter);
server.listen(8000, () => console.log(`Example app listening on ${port} port!`))



















